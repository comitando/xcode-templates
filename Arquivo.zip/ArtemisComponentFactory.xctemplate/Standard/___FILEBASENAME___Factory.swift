import ArtemisComponents
import ArtemisComponentsInterface
import ArtemisCore
import ArtemisCoreInterface
import Foundation

final class ___VARIABLE_moduleName___Factory: MakeController {
    static func makeController() -> UIViewController {
        let controller = SampleController()
            controller.cellControllersLoad = {
                ___VARIABLE_moduleName___Style.allCases.map { style in
                    let cell = ___VARIABLE_moduleName___Cell.make(
                        dto: ___VARIABLE_moduleName___DTO(
                            tbd: "TBD"
                        )
                    )
                    cell.customView.setStyle(style)
                    return cell
                }
            }

        return controller
    }
}

final class ___VARIABLE_moduleName___Cell: UITableViewCell {
    lazy var customView: any ___VARIABLE_moduleName___Interface = {
        let converter = ArtemisConverter()
        return converter.to___VARIABLE_moduleName___()
    }()

    private let dto: ___VARIABLE_moduleName___DTO
    init(dto: ___VARIABLE_moduleName___DTO) {
        self.dto = dto
        super.init(style: .default, reuseIdentifier: "custom")
        buildLayout()
    }

    required init?(coder: NSCoder) {
        nil
    }

    func buildLayout() {
        contentView.addSubview(customView)
        customView.snp.makeConstraints {
            $0.edges.equalToSuperview().inset(16)
        }

        customView
            .setDTO(dto)
            .onLoad { [weak self] dto in
                print(">>>> ___VARIABLE_moduleName___ on load \(dto)")
            }
            .onAppear { [weak self] dto in
                print(">>>> ___VARIABLE_moduleName___ on appear \(dto)")
            }

            customView.onAppear()
    }

    static func make(dto: ___VARIABLE_moduleName___DTO) -> ___VARIABLE_moduleName___Cell {
        return ___VARIABLE_moduleName___Cell(dto: dto)
    }
}
