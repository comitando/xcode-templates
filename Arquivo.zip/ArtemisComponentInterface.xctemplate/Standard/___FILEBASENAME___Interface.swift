import ArtemisCoreInterface
import Foundation

public enum ___VARIABLE_moduleName___Style: String, Decodable, CaseIterable, Equatable {
    // TODO: - Definir os tipos de Estilo que o componente terá
    case tbd
}

public protocol ___VARIABLE_moduleName___StyleProtocol {
    // TODO: - Definir propriedades que poderam ser expostas no estilo do componente
    var tbdColor: UIColor { get }
}

public struct ___VARIABLE_moduleName___DTO: Decodable, Equatable, DTOProtocol {
    // TODO: - Definir propriedades do DTO
    public let tbd: String

    public init(tbd: String) {
        self.tbd = tbd
    }
}

public protocol ___VARIABLE_moduleName___Interface: ComponentProtocol, ComponentLoadEventProtocol, RemakeConstraintProtocol {
    @discardableResult
    func setStyle(_ style: ___VARIABLE_moduleName___Style) -> Self
    @discardableResult
    func setDTO(_ dto: ___VARIABLE_moduleName___DTO) -> Self
}
