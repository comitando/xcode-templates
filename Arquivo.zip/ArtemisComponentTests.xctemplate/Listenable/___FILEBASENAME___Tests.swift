@testable import ArtemisComponents
import ArtemisComponentsInterface
import ArtemisCoreInterface
import ArtemisTesting
import TestKit
import XCTest

final class ___VARIABLE_moduleName___Tests: XCTestCase {
    func test___VARIABLE_moduleName____withAnatomyValues_forGoldTheme() {
        let (sut, theme) = makeSUT(.setupGoldMock())

        XCTAssertEqual(sut.style, .tbd)
        XCTAssertTrue(sut.tbdLabel.title.isEmpty)
        XCTAssertEqual(sut.anatomyProperties.titleFont.name, theme.fonts.smallRegular.name)
        XCTAssertEqual(sut.anatomyProperties.textAlignment, .left)
    }

    func test___VARIABLE_moduleName____withAnatomyValues_forEpicTheme() {
        let (sut, theme) = makeSUT(.setupEpicMock())

        XCTAssertEqual(sut.style, .tbd)
        XCTAssertTrue(sut.tbdLabel.title.isEmpty)
        XCTAssertEqual(sut.anatomyProperties.titleFont.name, theme.fonts.smallRegular.name)
        XCTAssertEqual(sut.anatomyProperties.textAlignment, .left)
    }

        func test___VARIABLE_moduleName____withTitle_shouldChangeText() {
        let firstString = "test"
        let (sut, _) = makeSUT(.setupGoldMock())
        sut.setDTO(.init(tbd: firstString, tbdIsEnabled: true))
        XCTAssertEqual(sut.tbdLabel.title, firstString)
        XCTAssertEqual(sut.dto?.tbdIsEnabled, true)

        let secondString = "second test"
        sut.setDTO(.init(tbd: secondString, tbdIsEnabled: false))
        XCTAssertEqual(sut.tbdLabel.title, secondString)
        XCTAssertEqual(sut.dto?.tbdIsEnabled, false)
    }

    func test___VARIABLE_moduleName____WithoutDTO_shouldntTriggerEvents() {
        let (sut, _) = makeSUT(.setupGoldMock())
        var dtoMessages: [___VARIABLE_moduleName___DTO] = []
        sut
            .onLoad { dto in
                guard let dto = dto as? ___VARIABLE_moduleName___DTO else { return }
                dtoMessages.append(dto)
            }
            .onAppear { dto in
                guard let dto = dto as? ___VARIABLE_moduleName___DTO else { return }
                dtoMessages.append(dto)
            }
            .onClick { dto in
                guard let dto = dto as? ___VARIABLE_moduleName___DTO else { return }
                dtoMessages.append(dto)
            }
            .onChange { dto in
                guard let dto = dto as? ___VARIABLE_moduleName___DTO else { return }
                dtoMessages.append(dto)
            }

        sut.onAppear()
        sut.onContainerClick()

        XCTAssertEqual(dtoMessages.count, 0)
    }

    func test___VARIABLE_moduleName____WithDTO_shouldTriggerEvents() {
        let dto = ___VARIABLE_moduleName___DTO(tbd: "test", tbdIsEnabled: true)
        let (sut, _) = makeSUT(.setupGoldMock())
        var dtoMessages: [___VARIABLE_moduleName___DTO] = []
        sut
            .setDTO(dto)
            .onLoad { dto in
                guard let dto = dto as? ___VARIABLE_moduleName___DTO else { return }
                dtoMessages.append(dto)
            }
            .onAppear { dto in
                guard let dto = dto as? ___VARIABLE_moduleName___DTO else { return }
                dtoMessages.append(dto)
            }
            .onClick { dto in
                guard let dto = dto as? ___VARIABLE_moduleName___DTO else { return }
                dtoMessages.append(dto)
            }
            .onChange { dto in
                guard let dto = dto as? ___VARIABLE_moduleName___DTO else { return }
                dtoMessages.append(dto)
            }

        sut.onAppear()
        sut.onContainerClick()

        XCTAssertEqual(
            dtoMessages,
            [dto, dto, dto, dto.copy(\.tbdIsEnabled, to: false)]
        )
    }

    func test___VARIABLE_moduleName____WithStyles_shouldOverrideProperties() {
        let (sut, theme) = makeSUT(.setupGoldMock())
        ___VARIABLE_moduleName___Style.allCases.forEach {
            let tbdColor: UIColor

            switch $0 {
            case .tbd:
                tbdColor = theme.colors.accentA
            }

            sut.setStyle($0)

            let style = sut.style.toStyle(theme.getTheme())
            XCTAssertEqual(sut.style, $0)
            XCTAssertEqual(style.tbdColor, tbdColor)
        }
    }
}

extension ___VARIABLE_moduleName___Tests {
    func makeSUT(
        _ dependencies: DependencyContainerMock,
        file: StaticString = #file,
        line: UInt = #line
    ) -> (___VARIABLE_moduleName___View, ThemeTokensInterface) {
        let sut = ___VARIABLE_moduleName___View(dependencies: dependencies)
        trackForMemoryLeaks(sut, file: file, line: line)
        return (sut, dependencies.themeTokens)
    }
}
