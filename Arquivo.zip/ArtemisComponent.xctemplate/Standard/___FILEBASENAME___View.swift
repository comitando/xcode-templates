import ArtemisComponentsInterface
import ArtemisCoreInterface
import AssetsKit
import Lottie
import SnapKit
import UIKit

// swiftlint:disable all
extension ArtemisConverter {
    public func to___VARIABLE_moduleName___() -> any ___VARIABLE_moduleName___Interface {
        ___VARIABLE_moduleName___View(dependencies: dependencies)
    }
}

final class ___VARIABLE_moduleName___View: UIView {
    // MARK: - Typealias
    typealias Style = ___VARIABLE_moduleName___Style
    typealias DTO = ___VARIABLE_moduleName___DTO
    typealias Dependencies = HasThemeTokensInterface & HasArtemisBaseComponentsInterface

    // MARK: - Anatomy configurations
    struct AnatomyConfiguration {
        lazy var titleFont: FontStyleProtocol = dependencies.themeTokens.fonts.smallRegular
        lazy var textAlignment: NSTextAlignment = .left

        let dependencies: Dependencies

        init(dependencies: Dependencies) {
            self.dependencies = dependencies
        }
    }

    lazy var anatomyProperties = AnatomyConfiguration(dependencies: dependencies)

    // MARK: - UI Properties
    lazy var tbdLabel = dependencies.artemisBaseComponents.toText()

    // MARK: - Configuration Properties
    private(set) var style: Style
    private let dependencies: Dependencies
    private var dto: DTO?
    var onAppearCallback: ((DTOProtocol) -> Void)?
    var remakeConstraints: ((ConstraintMakerProtocol) -> Void)? {
        didSet {
            setupComponentConstraints()
        }
    }


    // MARK: - Instance
    required init(style: Style = .tbd, dependencies: Dependencies? = nil) {
        self.style = style
        self.dependencies = dependencies ?? DependencyContainer()
        super.init(frame: .zero)
        buildLayout()
    }

    @available(*, unavailable)
    internal required init?(coder: NSCoder) {
        nil
    }
}

// MARK: - Setup ViewConfiguration
extension ___VARIABLE_moduleName___View: ArtemisViewConfiguration {
    func buildViewHierarchy() {
        addSubview(tbdLabel)
    }

    func setupComponentConstraints() {
        snp.remakeConstraints {
            remakeConstraints?($0)
        }
    }

    func setupConstraints() {
        setupComponentConstraints()
        tbdLabel.snp.remakeConstraints {
            $0.edges.equalToSuperview()
        }
    }

    func configureViews() {
        tbdLabel.font(anatomyProperties.titleFont)
        [tbdLabel].forEach {
            $0.textAlignment = anatomyProperties.textAlignment
        }

    }

    func configureStyles() {
        let style = style.toStyle(dependencies.themeTokens.getTheme())
        tbdLabel.foreground(color: style.tbdColor)
    }

    func configureAccessibility() {
        tbdLabel.isAccessibilityElement = false
        tbdLabel.isUserInteractionEnabled = false
    }
}

// MARK: - ___VARIABLE_moduleName___Interface
extension ___VARIABLE_moduleName___View: ___VARIABLE_moduleName___Interface {
    @discardableResult
    func setStyle(_ style: Style) -> Self {
        self.style = style
        updateView()
        return self
    }

    @discardableResult
    func setDTO(_ dto: ___VARIABLE_moduleName___DTO) -> Self {
        self.dto = dto
        tbdLabel.markdown(dto.tbd)
        fillAccessibility(with: dto)
        return self
    }


    @discardableResult
    func onLoad(_ callback: @escaping (DTOProtocol) -> Void) -> Self {
        guard let dto else { return self }
        callback(dto)
        return self
    }
    @discardableResult
    func onAppear() -> Self {
        guard let dto else { return self }
        self.onAppearCallback?(dto)
        return self
    }

    @discardableResult
    func onAppear(_ callback: @escaping (DTOProtocol) -> Void) -> Self {
        self.onAppearCallback = callback
        return self
    }
}

// MARK: - Accessibility
private extension ___VARIABLE_moduleName___View {
    func fillAccessibility(with dto: DTO) {
        accessibilityValue = dto.accessibilityValue
    }
}

extension ___VARIABLE_moduleName___DTO {
    var accessibilityValue: String {
        tbd
    }
}