import ArtemisComponentsInterface
import ArtemisCoreInterface
import Foundation

final class TBD___VARIABLE_moduleName___Style: ___VARIABLE_moduleName___StyleProtocol {
    var tbdColor: UIColor
    init(_ theme: ThemeProtocol) {
        tbdColor = theme.colors.accentA
    }
}

extension ___VARIABLE_moduleName___Style {
    func toStyle(_ theme: ThemeProtocol) -> ___VARIABLE_moduleName___StyleProtocol {
        switch self {
        case .tbd:
            return TBD___VARIABLE_moduleName___Style(theme)
        }
    }
}
